class Book < ApplicationRecord

validates :title, presence: true
validates :body, presence: true
validates :body,    length: { maximum: 200 }      # 「200文字以下」

# userモデルとアソシエーション（関連付け）
belongs_to :user


end
