class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
  attachment :profile_image
  validates :name,    length: { in: 2..20 }      # 「2文字以上20文字以下」
  validates :introduction,    length: { maximum: 50 }      # 「50文字以下」
  validates :name, uniqueness: { message: 'has already been taken' }

  # Bookモデルとアソシエーション（関連付け）
  has_many :books, dependent: :destroy
  # favoritesモデルとアソシエーション（関連付け）
  has_many :favorites, dependent: :destroy



end
