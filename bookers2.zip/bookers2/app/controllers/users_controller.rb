class UsersController < ApplicationController
  before_action :authenticate_user!

  def index
    @users = User.all
    @book = Book.new
    @user = User.find(current_user.id)

  end

  def show
   @user = User.find(params[:id])

   @book = Book.new
   # ユーザー/showの一覧表示（<% @books.each do |book| %>)に対してのコントローラ
   @books = Book.all
   @books = Book.where(user_id: @user.id)

  end

  def edit
     @user = User.find(params[:id])
     # ユーザーの編集を、ユーザー以外にさせない
     if @user == current_user
            render "edit"
     else
            redirect_to  current_user
     end

  end

  def update
    # DB保存されている、ログインしているユーザーの情報をとってきて（＝find）、更新対象とする。
    # edit.html.erbで必要なインスタンス変数(@xxx)は
    # render :editが実行される前にupdateアクション内ですべて準備してあげる必要
    @user = User.find(current_user.id)
    # if もしユーザー情報をアップデート（更新）するときに・・・
    if @user.update(user_params)
      flash[:notice] = 'Welcome! You have signed up successfully.'
    # OKであれば、ユーザーのページに戻る
    # redirect_to は、controller　→　URL　→　route　→　controller　→　view・・・ブラウザ上でHTTPリクエストを受けたのと同じ処理データ更新/削除が必要な場合＝controllerの処理が必要
    redirect_to user_path and return
     
    # モデルに設定しているバリテーションに引っかかってNGの場合は、editページにとどまる
    # render は、controller　→　view・・・直接、ビューを表示　ログインや入力形式に失敗した場合など　＝　ただエラーを表示させるだけ
    else
    render :edit
    end
   
  end



  private
  def user_params
    #画僧反映　西村先生の指導
      params.require(:user).permit(:name, :profile_image, :introduction )
    #画僧反映　西村先生の指導
  end

end
