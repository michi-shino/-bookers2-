class BooksController < ApplicationController
    before_action :authenticate_user!


  def new
   @book = Book.new
   @user = current_user.id
  end

  def index
    @books = Book.all
    @book = Book.new
    @user = User.find(current_user.id)

  end

  def show
   @book = Book.find(params[:id])
   # bookers2/app/views/books/show.html.erb 部分テンプレートを呼び出す箇所では<%= render 'books/newbook', book: @book %>と指定しております。ここでいう@bookはコントローラですでに保存してある詳細データが入っておりますが
   # 新規投稿用（New Book用）の空のインスタンスを渡してあげる必要があるのです。
   @new_book = Book.new
   # 今ログインしをるユーザー（current_user)ので、Userの情報を探して(find) @userへ格納
   @user = User.find(current_user.id)


  end

  def create
    @book = Book.new(book_params)
    @books = Book.all
    @book.user_id = current_user.id
    @user = User.find(current_user.id)

    if @book.save
      # flashというハッシュに :notice をいうキーで 'Welcome! You have signed up successfully.' という文字列の値を保存
      flash[:notice] = 'Welcome! You have signed up successfully.'
    redirect_to book_path(@book.id)
    else
      render :index
    end
  end

  def edit
    @book = Book.find(params[:id])
   # ユーザーの編集を、ユーザー以外にさせない
     if @book.user == current_user
            render "edit"
     else
            redirect_to  books_path
     end

  end

  def update
    @book = Book.find(params[:id])
    @books = Book.all
   if @book.update(book_params)
      # flashというハッシュに :notice をいうキーで 'Welcome! You have signed up successfully.' という文字列の値を保存
      flash[:notice] = 'Welcome! You have signed up successfully.'
    redirect_to book_path(@book.id)
   else
     render :edit
   end
  end

  def destroy
    # ---- ここからコードを書きましょう ---- #
    book = Book.find(params[:id])  # データ（レコード）を1件取得
    book.destroy  # データ（レコード）を削除
    redirect_to books_path  # books一覧画面へリダイレクト
    # ---- ここまでのあいだにコードを書きましょう ---- #
  end


  private
  def book_params
    params.require(:book).permit(:title, :body, :opinion,)
  end

end
