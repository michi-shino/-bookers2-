Rails.application.routes.draw do

  devise_for :users
  root to: 'homes#top'
  get 'home/about' => 'homes#about'

  resources :books, only: [:index, :create, :show, :edit, :update, :destroy,]
  resources :users, only: [:index, :show, :edit, :update]
  # favorites=お気に入り
  # resource=単数　favoritesのshowページが不要で、idの受け渡しも必要ないので、resourceとなっています。
  resource :favorites, only: [:create, :destroy]
end