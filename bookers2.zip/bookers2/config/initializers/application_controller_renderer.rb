# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end 
#画僧反映　西村先生の指導
Refile.secret_key = 'ed90aeddae2f6cae4a73a6277c54e5d32c7db4bca2605cde4f49b795e8397d41200c519f2cdac7917e10dde376d41eab473045763210179f92e0bd8fb9062369'
#画僧反映　西村先生の指導